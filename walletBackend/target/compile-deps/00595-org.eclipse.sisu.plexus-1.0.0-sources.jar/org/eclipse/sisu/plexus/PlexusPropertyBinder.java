/*
 * Copyright (c) 2010-2026 Sonatype, Inc. and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Stuart McCulloch (Sonatype, Inc.) - initial API and implementation
 */
package org.eclipse.sisu.plexus;

import com.google.inject.spi.TypeEncounter;
import javax.inject.Provider;
import org.codehaus.plexus.component.annotations.Configuration;
import org.codehaus.plexus.component.annotations.Requirement;
import org.eclipse.sisu.bean.BeanManager;
import org.eclipse.sisu.bean.BeanProperty;
import org.eclipse.sisu.bean.PropertyBinder;
import org.eclipse.sisu.bean.PropertyBinding;

/**
 * {@link PropertyBinder} that auto-binds properties according to Plexus metadata.
 */
final class PlexusPropertyBinder implements PropertyBinder {
    // ----------------------------------------------------------------------
    // Static initialization
    // ----------------------------------------------------------------------

    static {
        boolean optionalSupported = true;
        try {
            // support both old and new forms of @Requirement
            Requirement.class.getDeclaredMethod("optional");
        } catch (final LinkageError | Exception e) {
            optionalSupported = false;
        }
        OPTIONAL_SUPPORTED = optionalSupported;
    }

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    private static final boolean OPTIONAL_SUPPORTED;

    // ----------------------------------------------------------------------
    // Implementation fields
    // ----------------------------------------------------------------------

    private final BeanManager manager;

    private final PlexusBeanMetadata metadata;

    private final PlexusConfigurations configurations;

    private final PlexusRequirements requirements;

    // ----------------------------------------------------------------------
    // Constructors
    // ----------------------------------------------------------------------

    PlexusPropertyBinder(
            final BeanManager manager, final TypeEncounter<?> encounter, final PlexusBeanMetadata metadata) {
        this.manager = manager;
        this.metadata = metadata;

        configurations = new PlexusConfigurations(encounter);
        requirements = new PlexusRequirements(encounter);
    }

    // ----------------------------------------------------------------------
    // Public methods
    // ----------------------------------------------------------------------

    @Override
    public <T> PropertyBinding bindProperty(final BeanProperty<T> property) {
        if (metadata.isEmpty()) {
            return PropertyBinder.LAST_BINDING;
        }

        /*
         * @Configuration binding
         */
        final Configuration configuration = metadata.getConfiguration(property);
        if (null != configuration) {
            final Provider<T> valueProvider = configurations.lookup(configuration, property);
            return new ProvidedPropertyBinding<>(property, valueProvider);
        }

        /*
         * @Requirement binding
         */
        final Requirement requirement = metadata.getRequirement(property);
        if (null != requirement) {
            if (null != manager) {
                final PropertyBinding managedBinding = manager.manage(property);
                if (null != managedBinding) {
                    return managedBinding; // the bean manager will handle this property
                }
            }
            final Provider<T> roleProvider = requirements.lookup(requirement, property);
            if (OPTIONAL_SUPPORTED && requirement.optional()) {
                return new OptionalPropertyBinding<>(property, roleProvider);
            }
            return new ProvidedPropertyBinding<>(property, roleProvider);
        }

        return null; // nothing to bind
    }
}
