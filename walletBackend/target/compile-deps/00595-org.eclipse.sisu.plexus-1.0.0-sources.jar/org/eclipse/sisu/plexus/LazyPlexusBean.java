/*
 * Copyright (c) 2010-2026 Sonatype, Inc. and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Stuart McCulloch (Sonatype, Inc.) - initial API and implementation
 */
package org.eclipse.sisu.plexus;

import com.google.inject.name.Named;
import java.util.Map.Entry;
import org.eclipse.sisu.BeanEntry;

/**
 * {@link Entry} representing a lazy @{@link Named} Plexus bean; the bean is only retrieved when the value is requested.
 */
final class LazyPlexusBean<T> implements PlexusBean<T> {
    // ----------------------------------------------------------------------
    // Implementation fields
    // ----------------------------------------------------------------------

    private final BeanEntry<Named, T> bean;

    // ----------------------------------------------------------------------
    // Constructors
    // ----------------------------------------------------------------------

    LazyPlexusBean(final BeanEntry<Named, T> bean) {
        this.bean = bean;
    }

    // ----------------------------------------------------------------------
    // Public methods
    // ----------------------------------------------------------------------

    @Override
    public String getKey() {
        return bean.getKey().value();
    }

    @Override
    public T getValue() {
        return bean.getValue();
    }

    @Override
    public T setValue(final T value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String getDescription() {
        return bean.getDescription();
    }

    @Override
    public Class<T> getImplementationClass() {
        return bean.getImplementationClass();
    }

    @Override
    public String toString() {
        return getKey() + "=" + getValue();
    }
}
