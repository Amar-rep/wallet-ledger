/*
 * Copyright (c) 2010-2026 Sonatype, Inc. and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Stuart McCulloch (Sonatype, Inc.) - initial API and implementation
 */
package org.codehaus.plexus.logging;

import java.util.Map;
import org.codehaus.plexus.personality.plexus.lifecycle.phase.Initializable;
import org.eclipse.sisu.inject.Weak;
import org.eclipse.sisu.plexus.Roles;

public abstract class BaseLoggerManager extends AbstractLoggerManager implements Initializable {
    // ----------------------------------------------------------------------
    // Implementation fields
    // ----------------------------------------------------------------------

    private final Map<String, Logger> activeLoggers = Weak.values();

    String threshold = "INFO";

    private int currentThreshold;

    // ----------------------------------------------------------------------
    // Public methods
    // ----------------------------------------------------------------------

    @Override
    public final void initialize() {
        currentThreshold = parseThreshold(threshold);
    }

    @Override
    public final synchronized Logger getLoggerForComponent(final String role, final String hint) {
        final String name = Roles.canonicalRoleHint(role, hint);
        Logger logger = activeLoggers.get(name);
        if (null == logger) {
            logger = createLogger(name);
            logger.setThreshold(currentThreshold);
            activeLoggers.put(name, logger);
        }
        return logger;
    }

    @Override
    public final synchronized void returnComponentLogger(final String role, final String hint) {
        activeLoggers.remove(Roles.canonicalRoleHint(role, hint));
    }

    @Override
    public final int getThreshold() {
        return currentThreshold;
    }

    @Override
    public final void setThreshold(final int currentThreshold) {
        this.currentThreshold = currentThreshold;
    }

    @Override
    public final synchronized void setThresholds(final int currentThreshold) {
        this.currentThreshold = currentThreshold;
        for (final Logger logger : activeLoggers.values()) {
            logger.setThreshold(currentThreshold);
        }
    }

    public static final int parseThreshold(final String text) {
        if ("DEBUG".equalsIgnoreCase(text)) {
            return Logger.LEVEL_DEBUG;
        } else if ("INFO".equalsIgnoreCase(text)) {
            return Logger.LEVEL_INFO;
        } else if ("WARN".equalsIgnoreCase(text)) {
            return Logger.LEVEL_WARN;
        } else if ("ERROR".equalsIgnoreCase(text)) {
            return Logger.LEVEL_ERROR;
        } else if ("FATAL".equalsIgnoreCase(text)) {
            return Logger.LEVEL_FATAL;
        } else if ("DISABLED".equalsIgnoreCase(text)) {
            return Logger.LEVEL_DISABLED;
        }
        return Logger.LEVEL_DEBUG;
    }

    @Override
    public final synchronized int getActiveLoggerCount() {
        return activeLoggers.size();
    }

    // ----------------------------------------------------------------------
    // Customizable methods
    // ----------------------------------------------------------------------

    protected abstract Logger createLogger(String name);
}
