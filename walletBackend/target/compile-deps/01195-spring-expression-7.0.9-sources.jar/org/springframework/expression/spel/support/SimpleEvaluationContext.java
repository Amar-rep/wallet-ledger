/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.expression.spel.support;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.expression.BeanResolver;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.IndexAccessor;
import org.springframework.expression.MethodResolver;
import org.springframework.expression.OperatorOverloader;
import org.springframework.expression.PropertyAccessor;
import org.springframework.expression.TypeComparator;
import org.springframework.expression.TypeConverter;
import org.springframework.expression.TypeLocator;
import org.springframework.expression.TypedValue;
import org.springframework.expression.spel.SpelEvaluationException;
import org.springframework.expression.spel.SpelMessage;

/**
 * A basic implementation of {@link EvaluationContext} that focuses on a subset
 * of essential SpEL features and customization options, targeting simple
 * condition evaluation and in particular data binding scenarios.
 *
 * <p>In many cases, the full extent of the SpEL language is not required and
 * should be meaningfully restricted. Examples include but are not limited to
 * data binding expressions, property-based filters, and others. To that effect,
 * {@code SimpleEvaluationContext} is tailored to support only a subset of the
 * SpEL language syntax &mdash; for example, excluding references to Java types,
 * constructors, and bean references.
 *
 * <p>When creating a {@code SimpleEvaluationContext} you need to choose the level of
 * support that you need for data binding in SpEL expressions:
 * <ul>
 * <li>Data binding for read-only access</li>
 * <li>Data binding for read and write access</li>
 * <li>A custom {@code PropertyAccessor} (typically not reflection-based), potentially
 * combined with a {@link DataBindingPropertyAccessor}</li>
 * </ul>
 *
 * <p>Conveniently, {@link SimpleEvaluationContext#forReadOnlyDataBinding()} enables
 * read-only access to properties via {@link DataBindingPropertyAccessor}. Similarly,
 * {@link SimpleEvaluationContext#forReadWriteDataBinding()} enables read and write access
 * to properties. Alternatively, configure custom accessors via
 * {@link SimpleEvaluationContext#forPropertyAccessors}, consider
 * {@linkplain Builder#withAssignmentDisabled() disabling assignment} (recommended),
 * and optionally activate method resolution and/or a type converter through the
 * builder.
 *
 * <p>Note that {@code SimpleEvaluationContext} is typically not configured
 * with a default root object. Instead it is meant to be created once and
 * used repeatedly through {@code getValue} calls on a predefined
 * {@link org.springframework.expression.Expression} with both an
 * {@code EvaluationContext} and a root object as arguments:
 * {@link org.springframework.expression.Expression#getValue(EvaluationContext, Object)}.
 *
 * <p>In addition to support for setting and looking up variables as defined in
 * the {@link EvaluationContext} API, {@code SimpleEvaluationContext} also
 * provides support for {@linkplain #setVariable(String, Object) registering} and
 * {@linkplain #lookupVariable(String) looking up} functions as variables. Since
 * functions share a common namespace with the variables in this evaluation
 * context, care must be taken to ensure that function names and variable names
 * do not overlap.
 *
 * <p>For more power and flexibility, in particular for internal configuration
 * scenarios, consider using {@link StandardEvaluationContext} instead.
 *
 * <p><strong>WARNING</strong>: Although {@code SimpleEvaluationContext} restricts
 * the SpEL language to a subset of its features, that restriction is provided on
 * a best-effort basis and does not guarantee that evaluation of an expression is
 * safe; {@code SimpleEvaluationContext} must not be considered safe for evaluating
 * a SpEL expression obtained from an untrusted source. This responsibility extends
 * to property accessors: restricting a {@code SimpleEvaluationContext} to read-only
 * data binding governs only whether <em>assignment</em> to a property is permitted
 * and does not verify that reading a property is free of side effects. See the
 * <a href="https://docs.spring.io/spring-framework/reference/core/expressions/evaluation.html#expressions-evaluation-context-security"
 * >Security Considerations</a> and
 * <a href="https://docs.spring.io/spring-framework/reference/core/expressions/evaluation.html#expressions-evaluation-context-object-design"
 * >Object Design</a> sections of the Spring Framework reference documentation, as well
 * as the class-level documentation for {@link ReflectivePropertyAccessor} and
 * {@link DataBindingPropertyAccessor}, for details.
 *
 * <p>Because a parsed {@code Expression} may cache accessor and executor state
 * resolved against a particular {@code EvaluationContext} configuration, a parsed
 * {@code Expression} must never be evaluated first against a
 * {@code StandardEvaluationContext} (or any other, less restrictive,
 * {@code EvaluationContext}) and later against a {@code SimpleEvaluationContext}. If the
 * same expression string must be evaluated under both kinds of contexts, parse it into
 * two distinct {@code Expression} instances instead. See
 * {@link org.springframework.expression.Expression Expression} for further details on
 * this lifecycle contract.
 *
 * @author Rossen Stoyanchev
 * @author Juergen Hoeller
 * @author Sam Brannen
 * @since 4.3.15
 * @see #forReadOnlyDataBinding()
 * @see #forReadWriteDataBinding()
 * @see #forPropertyAccessors
 * @see StandardEvaluationContext
 * @see StandardTypeConverter
 * @see DataBindingPropertyAccessor
 * @see DataBindingMethodResolver
 */
public final class SimpleEvaluationContext implements EvaluationContext {

	private static final TypeLocator typeNotFoundTypeLocator = typeName -> {
		throw new SpelEvaluationException(SpelMessage.TYPE_NOT_FOUND, typeName);
	};


	private final TypedValue rootObject;

	private final List<PropertyAccessor> propertyAccessors;

	private final List<IndexAccessor> indexAccessors;

	private final List<MethodResolver> methodResolvers;

	private final TypeConverter typeConverter;

	private final TypeComparator typeComparator = StandardTypeComparator.INSTANCE;

	private final OperatorOverloader operatorOverloader = StandardOperatorOverloader.INSTANCE;

	private final Map<String, Object> variables = new HashMap<>();

	private final boolean assignmentEnabled;

	private final boolean compilationSupported;


	private SimpleEvaluationContext(List<PropertyAccessor> propertyAccessors, List<IndexAccessor> indexAccessors,
			List<MethodResolver> resolvers, @Nullable TypeConverter converter, @Nullable TypedValue rootObject,
			boolean assignmentEnabled, boolean compilationSupported) {

		this.propertyAccessors = propertyAccessors;
		this.indexAccessors = indexAccessors;
		this.methodResolvers = resolvers;
		this.typeConverter = (converter != null ? converter : new StandardTypeConverter());
		this.rootObject = (rootObject != null ? rootObject : TypedValue.NULL);
		this.assignmentEnabled = assignmentEnabled;
		this.compilationSupported = compilationSupported;
	}


	/**
	 * Return the specified root object, if any.
	 */
	@Override
	public TypedValue getRootObject() {
		return this.rootObject;
	}

	/**
	 * Return the specified {@link PropertyAccessor} delegates, if any.
	 * @see #forPropertyAccessors
	 */
	@Override
	public List<PropertyAccessor> getPropertyAccessors() {
		return this.propertyAccessors;
	}

	/**
	 * Return the specified {@link IndexAccessor} delegates, if any.
	 * @since 6.2
	 * @see Builder#withIndexAccessors(IndexAccessor...)
	 */
	@Override
	public List<IndexAccessor> getIndexAccessors() {
		return this.indexAccessors;
	}

	/**
	 * Return the specified {@link MethodResolver} delegates, if any.
	 * @see Builder#withMethodResolvers
	 */
	@Override
	public List<MethodResolver> getMethodResolvers() {
		return this.methodResolvers;
	}

	/**
	 * {@code SimpleEvaluationContext} does not support the use of bean references.
	 * @return always {@code null}
	 */
	@Override
	public @Nullable BeanResolver getBeanResolver() {
		return null;
	}

	/**
	 * {@code SimpleEvaluationContext} does not support use of type references.
	 * @return {@code TypeLocator} implementation that raises a
	 * {@link SpelEvaluationException} with {@link SpelMessage#TYPE_NOT_FOUND}
	 */
	@Override
	public TypeLocator getTypeLocator() {
		return typeNotFoundTypeLocator;
	}

	/**
	 * The configured {@link TypeConverter}.
	 * <p>By default this is {@link StandardTypeConverter}.
	 * @see Builder#withTypeConverter
	 * @see Builder#withConversionService
	 */
	@Override
	public TypeConverter getTypeConverter() {
		return this.typeConverter;
	}

	/**
	 * Return an instance of {@link StandardTypeComparator}.
	 */
	@Override
	public TypeComparator getTypeComparator() {
		return this.typeComparator;
	}

	/**
	 * Return an instance of {@link StandardOperatorOverloader}.
	 */
	@Override
	public OperatorOverloader getOperatorOverloader() {
		return this.operatorOverloader;
	}

	/**
	 * {@code SimpleEvaluationContext} does not support variable assignment within
	 * expressions.
	 * @throws SpelEvaluationException with {@link SpelMessage#VARIABLE_ASSIGNMENT_NOT_SUPPORTED}
	 * @since 5.2.24
	 */
	@Override
	public TypedValue assignVariable(String name, Supplier<TypedValue> valueSupplier) {
		throw new SpelEvaluationException(SpelMessage.VARIABLE_ASSIGNMENT_NOT_SUPPORTED, "#" + name);
	}

	/**
	 * Set a named variable or function in this evaluation context to the specified
	 * value.
	 * <p>A function can be registered as a {@link java.lang.reflect.Method} or
	 * a {@link java.lang.invoke.MethodHandle}.
	 * <p>Note that variables and functions share a common namespace in this
	 * evaluation context. See the {@linkplain SimpleEvaluationContext
	 * class-level documentation} for details.
	 * @param name the name of the variable or function to set
	 * @param value the value to be placed in the variable or function
	 * @see #lookupVariable(String)
	 */
	@Override
	public void setVariable(String name, @Nullable Object value) {
		this.variables.put(name, value);
	}

	/**
	 * Look up a named variable or function within this evaluation context.
	 * <p>Note that variables and functions share a common namespace in this
	 * evaluation context. See the {@linkplain SimpleEvaluationContext
	 * class-level documentation} for details.
	 * @param name the name of the variable or function to look up
	 * @return the value of the variable or function, or {@code null} if not found
	 */
	@Override
	public @Nullable Object lookupVariable(String name) {
		return this.variables.get(name);
	}

	/**
	 * Determine if assignment is enabled within expressions evaluated by this evaluation
	 * context.
	 * <p>If this method returns {@code false}, the assignment ({@code =}), increment
	 * ({@code ++}), and decrement ({@code --}) operators are disabled.
	 * @return {@code true} if assignment is enabled; {@code false} otherwise
	 * @since 5.3.38
	 * @see #forReadOnlyDataBinding()
	 * @see Builder#withAssignmentDisabled()
	 */
	@Override
	public boolean isAssignmentEnabled() {
		return this.assignmentEnabled;
	}

	/**
	 * Determine if compilation is supported within expressions evaluated by this evaluation
	 * context.
	 * <p>By default, compilation is not supported in {@code SimpleEvaluationContext}.
	 * @return {@code true} if compilation is supported; {@code false} otherwise
	 * @since 7.0.9
	 * @see Builder#withCompilationSupported()
	 */
	@Override
	public boolean isCompilationSupported() {
		return this.compilationSupported;
	}

	/**
	 * Create a {@code SimpleEvaluationContext} for the specified {@link PropertyAccessor}
	 * delegates: typically a custom {@code PropertyAccessor} specific to a use case &mdash;
	 * for example, for attribute resolution in a custom data structure &mdash; potentially
	 * combined with a {@link DataBindingPropertyAccessor} if property dereferences are
	 * needed as well.
	 * <p>By default, assignment is enabled within expressions evaluated by the context
	 * created via this factory method; however, assignment can be disabled via
	 * {@link Builder#withAssignmentDisabled()}.
	 * @param accessors the accessor delegates to use
	 * @see DataBindingPropertyAccessor#forReadOnlyAccess()
	 * @see DataBindingPropertyAccessor#forReadWriteAccess()
	 * @see #isAssignmentEnabled()
	 * @see Builder#withAssignmentDisabled()
	 */
	public static Builder forPropertyAccessors(PropertyAccessor... accessors) {
		for (PropertyAccessor accessor : accessors) {
			if (accessor.getClass() == ReflectivePropertyAccessor.class) {
				throw new IllegalArgumentException("SimpleEvaluationContext is not designed for use with a plain " +
						"ReflectivePropertyAccessor. Consider using DataBindingPropertyAccessor or a custom subclass.");
			}
		}
		return new Builder(accessors);
	}

	/**
	 * Create a {@code SimpleEvaluationContext} for read-only access to
	 * public properties via {@link DataBindingPropertyAccessor}.
	 * <p>Assignment is disabled within expressions evaluated by the context created via
	 * this factory method.
	 * @see DataBindingPropertyAccessor#forReadOnlyAccess()
	 * @see #forPropertyAccessors
	 * @see #isAssignmentEnabled()
	 * @see Builder#withAssignmentDisabled()
	 */
	public static Builder forReadOnlyDataBinding() {
		return new Builder(DataBindingPropertyAccessor.forReadOnlyAccess()).withAssignmentDisabled();
	}

	/**
	 * Create a {@code SimpleEvaluationContext} for read-write access to
	 * public properties via {@link DataBindingPropertyAccessor}.
	 * <p>By default, assignment is enabled within expressions evaluated by the context
	 * created via this factory method. Assignment can be disabled via
	 * {@link Builder#withAssignmentDisabled()}; however, it is preferable to use
	 * {@link #forReadOnlyDataBinding()} if you desire read-only access.
	 * @see DataBindingPropertyAccessor#forReadWriteAccess()
	 * @see #forPropertyAccessors
	 * @see #isAssignmentEnabled()
	 * @see Builder#withAssignmentDisabled()
	 */
	public static Builder forReadWriteDataBinding() {
		return new Builder(DataBindingPropertyAccessor.forReadWriteAccess());
	}


	/**
	 * Builder for {@code SimpleEvaluationContext}.
	 */
	public static final class Builder {

		private final List<PropertyAccessor> propertyAccessors;

		private List<IndexAccessor> indexAccessors = Collections.emptyList();

		private List<MethodResolver> resolvers = Collections.emptyList();

		private @Nullable TypeConverter typeConverter;

		private @Nullable TypedValue rootObject;

		private boolean assignmentEnabled = true;

		private boolean compilationSupported = false;


		private Builder(PropertyAccessor... accessors) {
			this.propertyAccessors = Arrays.asList(accessors);
		}


		/**
		 * Disable assignment within expressions evaluated by this evaluation context.
		 * @since 5.3.38
		 * @see SimpleEvaluationContext#isAssignmentEnabled()
		 */
		public Builder withAssignmentDisabled() {
			this.assignmentEnabled = false;
			return this;
		}

		/**
		 * Indicate that compilation is supported within expressions evaluated by this
		 * evaluation context.
		 * <p>By default, compilation is not supported in {@code SimpleEvaluationContext}.
		 * Call this method to opt in to compilation &mdash; for example, when evaluating
		 * trusted expressions where performance is critical.
		 * <p><strong>WARNING</strong>: Opting in to compilation for expressions from
		 * untrusted sources removes the safety guards supported in interpreted mode.
		 * @since 7.0.9
		 * @see SimpleEvaluationContext#isCompilationSupported()
		 */
		public Builder withCompilationSupported() {
			this.compilationSupported = true;
			return this;
		}

		/**
		 * Register the specified {@link IndexAccessor} delegates.
		 * @param indexAccessors the index accessors to use
		 * @since 6.2
		 */
		public Builder withIndexAccessors(IndexAccessor... indexAccessors) {
			this.indexAccessors = Arrays.asList(indexAccessors);
			return this;
		}

		/**
		 * Register the specified {@link MethodResolver} delegates for
		 * a combination of property access and method resolution.
		 * @param resolvers the resolver delegates to use
		 * @see #withInstanceMethods()
		 * @see SimpleEvaluationContext#forPropertyAccessors
		 */
		public Builder withMethodResolvers(MethodResolver... resolvers) {
			for (MethodResolver resolver : resolvers) {
				if (resolver.getClass() == ReflectiveMethodResolver.class) {
					throw new IllegalArgumentException("SimpleEvaluationContext is not designed for use with a plain " +
							"ReflectiveMethodResolver. Consider using DataBindingMethodResolver or a custom subclass.");
				}
			}
			this.resolvers = Arrays.asList(resolvers);
			return this;
		}

		/**
		 * Register a {@link DataBindingMethodResolver} for instance method invocation purposes
		 * (i.e. not supporting static methods) in addition to the specified property accessors,
		 * typically in combination with a {@link DataBindingPropertyAccessor}.
		 * @see #withMethodResolvers
		 * @see SimpleEvaluationContext#forReadOnlyDataBinding()
		 * @see SimpleEvaluationContext#forReadWriteDataBinding()
		 */
		public Builder withInstanceMethods() {
			this.resolvers = Collections.singletonList(DataBindingMethodResolver.forInstanceMethodInvocation());
			return this;
		}

		/**
		 * Register a custom {@link ConversionService}.
		 * <p>By default a {@link StandardTypeConverter} backed by a
		 * {@link org.springframework.core.convert.support.DefaultConversionService} is used.
		 * @see #withTypeConverter
		 * @see StandardTypeConverter#StandardTypeConverter(ConversionService)
		 */
		public Builder withConversionService(ConversionService conversionService) {
			this.typeConverter = new StandardTypeConverter(conversionService);
			return this;
		}

		/**
		 * Register a custom {@link TypeConverter}.
		 * <p>By default a {@link StandardTypeConverter} backed by a
		 * {@link org.springframework.core.convert.support.DefaultConversionService} is used.
		 * @see #withConversionService
		 * @see StandardTypeConverter#StandardTypeConverter()
		 */
		public Builder withTypeConverter(TypeConverter converter) {
			this.typeConverter = converter;
			return this;
		}

		/**
		 * Specify a default root object to resolve against.
		 * <p>Default is none, expecting an object argument at evaluation time.
		 * @see org.springframework.expression.Expression#getValue(EvaluationContext)
		 * @see org.springframework.expression.Expression#getValue(EvaluationContext, Object)
		 */
		public Builder withRootObject(Object rootObject) {
			this.rootObject = new TypedValue(rootObject);
			return this;
		}

		/**
		 * Specify a typed root object to resolve against.
		 * <p>Default is none, expecting an object argument at evaluation time.
		 * @see org.springframework.expression.Expression#getValue(EvaluationContext)
		 * @see org.springframework.expression.Expression#getValue(EvaluationContext, Object)
		 */
		public Builder withTypedRootObject(Object rootObject, TypeDescriptor typeDescriptor) {
			this.rootObject = new TypedValue(rootObject, typeDescriptor);
			return this;
		}

		public SimpleEvaluationContext build() {
			return new SimpleEvaluationContext(this.propertyAccessors, this.indexAccessors,
					this.resolvers, this.typeConverter, this.rootObject,
					this.assignmentEnabled, this.compilationSupported);
		}

	}

}
