/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.webresources.war;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.Permission;

import org.apache.tomcat.util.buf.UriUtil;


/**
 * URL connection for WAR resources that wraps a JAR URL connection.
 */
public class WarURLConnection extends URLConnection {

    /**
     * The wrapped JAR URL connection.
     */
    private final URLConnection wrappedJarUrlConnection;
    /**
     * Whether this connection has been established.
     */
    private boolean connected;

    /**
     * Constructs a new WarURLConnection.
     *
     * @param url The URL to connect to
     *
     * @throws IOException If an I/O error occurs
     */
    protected WarURLConnection(URL url) throws IOException {
        super(url);
        URL innerJarUrl = UriUtil.warToJar(url);
        wrappedJarUrlConnection = innerJarUrl.openConnection();
    }


    @Override
    public void connect() throws IOException {
        if (!connected) {
            wrappedJarUrlConnection.connect();
            connected = true;
        }
    }


    @Override
    public InputStream getInputStream() throws IOException {
        connect();
        return wrappedJarUrlConnection.getInputStream();
    }


    @Override
    @Deprecated
    public Permission getPermission() throws IOException {
        return wrappedJarUrlConnection.getPermission();
    }


    @Override
    public long getLastModified() {
        return wrappedJarUrlConnection.getLastModified();
    }


    @Override
    public int getContentLength() {
        return wrappedJarUrlConnection.getContentLength();
    }


    @Override
    public long getContentLengthLong() {
        return wrappedJarUrlConnection.getContentLengthLong();
    }

}
