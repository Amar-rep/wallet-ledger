package org.checkerframework.checker.index.qual;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.checkerframework.framework.qual.SubtypeOf;

/**
 * The bottom qualifier in the GrowShrink hierarchy. Programmers should rarely write this type.
 *
 * @checker_framework.manual #bottom-type the bottom type
 */
// Reinstate when lists are supported:
//  * @checker_framework.manual #growonly-checker Grow-only Checker
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@SubtypeOf({GrowOnly.class, UncheckedCanShrink.class})
public @interface BottomGrowShrink {}
