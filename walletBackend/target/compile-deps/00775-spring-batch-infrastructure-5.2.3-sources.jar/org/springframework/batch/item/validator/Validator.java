/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.batch.item.validator;

/**
 * Interface used to validate objects.
 *
 * @author tomas.slanina
 *
 */
public interface Validator<T> {

	/**
	 * Method used to validate if the value is valid.
	 * @param value object to be validated
	 * @throws ValidationException if value is not valid.
	 */
	void validate(T value) throws ValidationException;

}
