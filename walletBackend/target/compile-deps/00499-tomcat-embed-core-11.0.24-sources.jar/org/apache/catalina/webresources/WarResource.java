/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina.webresources;

import java.util.jar.JarEntry;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.apache.tomcat.util.buf.UriUtil;

/**
 * Represents a single resource (file or directory) that is located within a WAR.
 */
public class WarResource extends AbstractSingleArchiveResource {

    private static final Log log = LogFactory.getLog(WarResource.class);


    /**
     * Constructs a new WarResource.
     *
     * @param archiveResourceSet The archive resource set
     * @param webAppPath         The web application path
     * @param baseUrl            The base URL
     * @param jarEntry           The JAR entry
     */
    public WarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl,
            JarEntry jarEntry) {
        super(archiveResourceSet, webAppPath, "war:" + baseUrl + UriUtil.getWarSeparator(), jarEntry, baseUrl);
    }


    @Override
    protected Log getLog() {
        return log;
    }
}
