/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.tomcat.websocket.pojo;

import java.util.Map;

import jakarta.websocket.EndpointConfig;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpointConfig;

/**
 * Wrapper class for instances of POJOs annotated with {@link jakarta.websocket.server.ServerEndpoint} so they appear as
 * standard {@link jakarta.websocket.Endpoint} instances.
 */
public class PojoEndpointServer extends PojoEndpointBase {

    /**
     * Constructs a new PojoEndpointServer.
     *
     * @param pathParameters the path parameters for the endpoint
     * @param pojo the POJO instance annotated with {@code @ServerEndpoint}
     */
    public PojoEndpointServer(Map<String,String> pathParameters, Object pojo) {
        super(pathParameters);
        setPojo(pojo);
    }


    @Override
    public void onOpen(Session session, EndpointConfig endpointConfig) {

        ServerEndpointConfig sec = (ServerEndpointConfig) endpointConfig;

        PojoMethodMapping methodMapping =
                (PojoMethodMapping) sec.getUserProperties().get(Constants.POJO_METHOD_MAPPING_KEY);
        setMethodMapping(methodMapping);

        doOnOpen(session, endpointConfig);
    }
}
