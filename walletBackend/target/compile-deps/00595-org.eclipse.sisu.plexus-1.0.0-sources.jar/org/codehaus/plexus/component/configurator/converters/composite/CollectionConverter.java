/*
 * Copyright (c) 2010-2026 Sonatype, Inc. and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *   Stuart McCulloch (Sonatype, Inc.) - initial API and implementation
 */
package org.codehaus.plexus.component.configurator.converters.composite;

import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import org.codehaus.plexus.component.configurator.ComponentConfigurationException;
import org.codehaus.plexus.component.configurator.ConfigurationListener;
import org.codehaus.plexus.component.configurator.converters.ParameterizedConfigurationConverter;
import org.codehaus.plexus.component.configurator.converters.lookup.ConverterLookup;
import org.codehaus.plexus.component.configurator.expression.ExpressionEvaluator;
import org.codehaus.plexus.configuration.PlexusConfiguration;

public class CollectionConverter extends AbstractCollectionConverter implements ParameterizedConfigurationConverter {
    @Override
    public boolean canConvert(final Class<?> type) {
        return Collection.class.isAssignableFrom(type) && !Map.class.isAssignableFrom(type);
    }

    @Override
    public Object fromConfiguration(
            final ConverterLookup lookup,
            final PlexusConfiguration configuration,
            final Class<?> type,
            final Class<?> enclosingType,
            final ClassLoader loader,
            final ExpressionEvaluator evaluator,
            final ConfigurationListener listener)
            throws ComponentConfigurationException {
        return fromConfiguration(lookup, configuration, type, null, enclosingType, loader, evaluator, listener);
    }

    @Override
    public Object fromConfiguration(
            final ConverterLookup lookup,
            final PlexusConfiguration configuration,
            final Class<?> type,
            final Type[] typeArguments,
            final Class<?> enclosingType,
            final ClassLoader loader,
            final ExpressionEvaluator evaluator,
            final ConfigurationListener listener)
            throws ComponentConfigurationException {
        final Object value = fromExpression(configuration, evaluator, type, false);
        if (type.isInstance(value)) {
            return value;
        }
        try {
            final Collection<Object> elements;
            final Type elementType = findElementType(typeArguments);
            if (null == value) {
                elements = fromChildren(
                        lookup, configuration, type, enclosingType, loader, evaluator, listener, elementType);
            } else if (value instanceof String) {
                final PlexusConfiguration xml = csvToXml(configuration, (String) value);
                elements = fromChildren(lookup, xml, type, enclosingType, loader, evaluator, listener, elementType);
            } else if (value instanceof Object[]) {
                elements = instantiateCollection(configuration, type, loader);
                Collections.addAll(elements, (Object[]) value);
            } else {
                failIfNotTypeCompatible(value, type, configuration);
                elements = Collections.emptyList(); // unreachable
            }
            return elements;
        } catch (final ComponentConfigurationException e) {
            if (null == e.getFailedConfiguration()) {
                e.setFailedConfiguration(configuration);
            }
            throw e;
        } catch (final IllegalArgumentException e) {
            throw new ComponentConfigurationException(configuration, "Cannot store value into collection", e);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected final Collection<Object> instantiateCollection(
            final PlexusConfiguration configuration, final Class<?> type, final ClassLoader loader)
            throws ComponentConfigurationException {
        final Class<?> implType = getClassForImplementationHint(type, configuration, loader);
        if (null == implType || Modifier.isAbstract(implType.getModifiers())) {
            if (Set.class.isAssignableFrom(type)) {
                if (SortedSet.class.isAssignableFrom(type)) {
                    return new TreeSet<>();
                }
                return new HashSet<>();
            }
            return new ArrayList<>();
        }

        final Object impl = instantiateObject(implType);
        failIfNotTypeCompatible(impl, type, configuration);
        return (Collection<Object>) impl;
    }

    private static Type findElementType(final Type[] typeArguments) {
        if (null != typeArguments && typeArguments.length > 0) {
            return typeArguments[0];
        }
        return Object.class;
    }
}
