/*
 * Copyright 2004, 2005, 2006 Acegi Technology Pty Limited
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.authentication.jaas;

import java.security.Principal;

import org.jspecify.annotations.Nullable;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.Assert;

/**
 * {@code GrantedAuthority} which, in addition to the assigned role, holds the principal
 * that an {@link AuthorityGranter} used as a reason to grant this authority.
 *
 * @author Ray Krueger
 * @see AuthorityGranter
 */
public final class JaasGrantedAuthority implements GrantedAuthority {

	private static final long serialVersionUID = 620L;

	private final String role;

	private final Principal principal;

	public JaasGrantedAuthority(String role, Principal principal) {
		Assert.notNull(role, "role cannot be null");
		Assert.notNull(principal, "principal cannot be null");
		this.role = role;
		this.principal = principal;
	}

	public Principal getPrincipal() {
		return this.principal;
	}

	@Override
	public String getAuthority() {
		return this.role;
	}

	@Override
	public boolean equals(@Nullable Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj instanceof JaasGrantedAuthority jga) {
			return this.role.equals(jga.getAuthority()) && this.principal.equals(jga.getPrincipal());
		}
		return false;
	}

	@Override
	public int hashCode() {
		int result = this.principal.hashCode();
		result = 31 * result + this.role.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return "Jaas Authority [" + this.role + "," + this.principal + "]";
	}

}
