/*
 *
 *  *
 *  *  *
 *  *  *  *
 *  *  *  *  *
 *  *  *  *  *  * Copyright 2019-2026 the original author or authors.
 *  *  *  *  *  *
 *  *  *  *  *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  *  *  *  *  * you may not use this file except in compliance with the License.
 *  *  *  *  *  * You may obtain a copy of the License at
 *  *  *  *  *  *
 *  *  *  *  *  *      https://www.apache.org/licenses/LICENSE-2.0
 *  *  *  *  *  *
 *  *  *  *  *  * Unless required by applicable law or agreed to in writing, software
 *  *  *  *  *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  *  *  *  *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  *  *  *  * See the License for the specific language governing permissions and
 *  *  *  *  *  * limitations under the License.
 *  *  *  *  *
 *  *  *  *
 *  *  *
 *  *
 *
 */

package org.springdoc.core.converters;

import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JavaType;
import io.swagger.v3.core.converter.AnnotatedType;
import io.swagger.v3.core.converter.ModelConverter;
import io.swagger.v3.core.converter.ModelConverterContext;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.media.Schema;
import org.springdoc.core.providers.ObjectMapperProvider;

import org.springframework.core.ResolvableType;
import org.springframework.data.web.PagedModel;

/**
 * The Spring Data Page type model converter.
 *
 * @author Claudio Nave
 */
public class PageOpenAPIConverter implements ModelConverter {

	/**
	 * The constant PAGE_TO_REPLACE.
	 */
	private static final String PAGE_TO_REPLACE = "org.springframework.data.domain.Page";

	/**
	 * The constant PAGED_MODEL.
	 */
	private static final AnnotatedType PAGED_MODEL = new AnnotatedType(PagedModel.class).resolveAsRef(true);

	/**
	 * The standard page response property order.
	 */
	private static final List<String> PAGE_PROPERTY_ORDER = List.of(
			"totalPages",
			"totalElements",
			"size",
			"content",
			"number",
			"sort",
			"pageable",
			"numberOfElements",
			"first",
			"last",
			"empty"
	);

	/**
	 * The Spring doc object mapper.
	 */
	private final ObjectMapperProvider springDocObjectMapper;

	/**
	 * Flag to replace Page with PagedModel or not.
	 */
	private final boolean replacePageWithPagedModel;

	/**
	 * Instantiates a new Page open api converter.
	 *
	 * @param replacePageWithPagedModel flag to replace Page with PagedModel or not
	 * @param springDocObjectMapper     the spring doc object mapper
	 */
	public PageOpenAPIConverter(boolean replacePageWithPagedModel, ObjectMapperProvider springDocObjectMapper) {
		this.replacePageWithPagedModel = replacePageWithPagedModel;
		this.springDocObjectMapper = springDocObjectMapper;
	}

	/**
	 * Resolve schema.
	 *
	 * @param type    the type
	 * @param context the context
	 * @param chain   the chain
	 * @return the schema
	 */
	@Override
	public Schema resolve(AnnotatedType type, ModelConverterContext context, Iterator<ModelConverter> chain) {
		JavaType javaType = springDocObjectMapper.jsonMapper().constructType(type.getType());
		boolean isPageType = false;
		if (javaType != null) {
			Class<?> cls = javaType.getRawClass();
			isPageType = PAGE_TO_REPLACE.equals(cls.getCanonicalName());
			if (replacePageWithPagedModel && isPageType) {
				if (!type.isSchemaProperty())
					type = resolvePagedModelType(javaType, type);
				else
					type.type(pagedModelType(javaType)).resolveAsRef(true);
			}
		}
		Schema schema = (chain.hasNext()) ? chain.next().resolve(type, context, chain) : null;

		if (isPageType && !replacePageWithPagedModel)
			sortPageSchemaProperties(schema, context);
		return schema;
	}

	/**
	 * Resolve paged model type annotated type.
	 *
	 * @param type the type
	 * @return the annotated type
	 */
	private AnnotatedType resolvePagedModelType(JavaType type, AnnotatedType originalType) {
		if (type.hasGenericTypes()) {
			return new AnnotatedType(pagedModelType(type))
					.resolveAsRef(true)
					.ctxAnnotations(originalType.getCtxAnnotations());
		}
		else {
			return PAGED_MODEL;
		}
	}

	/**
	 * The PagedModel type matching the given Page type.
	 *
	 * @param type the page type
	 * @return the paged model type
	 */
	private Type pagedModelType(JavaType type) {
		if (type.hasGenericTypes()) {
			JavaType innerType = type.containedType(0);
			return ResolvableType
					.forClassWithGenerics(PagedModel.class, ResolvableType.forType(innerType))
					.getType();
		}
		return PagedModel.class;
	}

	/**
	 * Sort page schema properties.
	 *
	 * @param schema  the schema
	 * @param context the context
	 */
	private void sortPageSchemaProperties(Schema schema, ModelConverterContext context) {
		Schema pageSchema = resolveReferencedSchema(schema, context);
		if (pageSchema == null || pageSchema.getProperties() == null)
			return;

		Map<String, Schema> properties = pageSchema.getProperties();
		if (!properties.keySet().containsAll(PAGE_PROPERTY_ORDER))
			return;

		Map<String, Schema> sortedProperties = new LinkedHashMap<>();
		PAGE_PROPERTY_ORDER.forEach(property -> sortedProperties.put(property, properties.get(property)));
		properties.forEach(sortedProperties::putIfAbsent);
		pageSchema.setProperties(sortedProperties);
	}

	/**
	 * Resolve referenced schema.
	 *
	 * @param schema  the schema
	 * @param context the context
	 * @return the schema
	 */
	private Schema resolveReferencedSchema(Schema schema, ModelConverterContext context) {
		if (schema == null || schema.get$ref() == null)
			return schema;

		String ref = schema.get$ref();
		if (!ref.startsWith(Components.COMPONENTS_SCHEMAS_REF))
			return schema;

		return context.getDefinedModels().get(ref.substring(Components.COMPONENTS_SCHEMAS_REF.length()));
	}

}
