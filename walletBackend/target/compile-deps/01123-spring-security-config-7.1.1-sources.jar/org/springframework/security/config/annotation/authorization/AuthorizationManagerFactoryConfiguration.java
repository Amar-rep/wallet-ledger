/*
 * Copyright 2004-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.security.config.annotation.authorization;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportAware;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.security.authorization.AuthorizationManagerFactories;
import org.springframework.security.authorization.AuthorizationManagerFactories.AdditionalRequiredFactorsBuilder;
import org.springframework.security.authorization.DefaultAuthorizationManagerFactory;
import org.springframework.security.config.Customizer;

/**
 * Uses {@link EnableMultiFactorAuthentication} to configure a
 * {@link DefaultAuthorizationManagerFactory}.
 *
 * @author Rob Winch
 * @since 7.0
 * @see EnableMultiFactorAuthentication
 */
class AuthorizationManagerFactoryConfiguration implements ImportAware {

	private String[] authorities;

	@Bean
	DefaultAuthorizationManagerFactory authorizationManagerFactory(
			List<Customizer<AdditionalRequiredFactorsBuilder<Object>>> additionalRequiredFactorsCustomizers) {
		AdditionalRequiredFactorsBuilder<Object> builder = AuthorizationManagerFactories.multiFactor()
			.requireFactors(this.authorities);
		for (Customizer<AdditionalRequiredFactorsBuilder<Object>> customizer : additionalRequiredFactorsCustomizers) {
			customizer.customize(builder);
		}
		return builder.build();
	}

	@Override
	public void setImportMetadata(AnnotationMetadata importMetadata) {
		Map<String, Object> multiFactorAuthenticationAttrs = importMetadata
			.getAnnotationAttributes(EnableMultiFactorAuthentication.class.getName());

		this.authorities = (String[]) multiFactorAuthenticationAttrs.getOrDefault("authorities", new String[0]);
	}

}
